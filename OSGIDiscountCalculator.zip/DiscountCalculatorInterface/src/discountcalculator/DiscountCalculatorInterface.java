package discountcalculator;



public interface DiscountCalculatorInterface {
	
	  public double calculateDiscount(double initialPrice,double discount);
}
